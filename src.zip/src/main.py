import time
from src.puzzle_generator import generate_problem
from src.tracker import PerformanceTracker
from src.adaptive_engine import RuleBasedAdaptiveEngine, MLAdaptiveEngine


def select_initial_difficulty():
    while True:
        v = input(
            'Choose initial difficulty (Easy / Medium / Hard) [Easy]: ').strip()
        if not v:
            return 'Easy'
        if v.capitalize() in ['Easy', 'Medium', 'Hard']:
            return v.capitalize()
        print('Please enter Easy, Medium or Hard')


def get_user_answer(prompt):
    s = input(prompt + ' ')
    try:
        return int(s)
    except Exception:
        return None


def run_session():
    print('Welcome to Math Adventures!')
    name = input('Enter learner name: ').strip() or 'Learner'
    difficulty = select_initial_difficulty()
    tracker = PerformanceTracker()
    rule_engine = RuleBasedAdaptiveEngine()
    ml_engine = MLAdaptiveEngine()

    rounds = 12
    for i in range(rounds):
        question, correct_ans, meta = generate_problem(difficulty)
        print(f'Problem {i+1}/{rounds} — Difficulty: {difficulty}')
        print(question)
        start = time.time()
        user = get_user_answer('Your answer:')
        rt = time.time() - start
        correct = (user == correct_ans)
        tracker.add_entry(
            question, correct_ans, user if user is not None else -999, correct, rt, difficulty)

        # Train ML engine occasionally and get ML suggestion
        try:
            ml_engine.train(tracker)
        except Exception:
            pass

        # Decide next difficulty: combine rule-based and ML if ML trained
        next_d_rule = rule_engine.get_next_difficulty(difficulty, tracker)
        next_d_ml = ml_engine.get_next_difficulty(difficulty, tracker)

        # Simple tie-breaking: if ML trained, prefer ML when it differs; else use rule.
        if getattr(ml_engine, 'trained', False) and next_d_ml != difficulty:
            next_d = next_d_ml
            source = 'ML'
        else:
            next_d = next_d_rule
            source = 'Rule'

        print(f"{'Correct!' if correct else 'Not quite.'} (Answer: {correct_ans}) — response time: {rt:.1f}s")
        if next_d != difficulty:
            print(
                f"Difficulty will change: {difficulty} -> {next_d} (by {source})")
        else:
            print('Difficulty stays the same.')
        difficulty = next_d
        print('-'*40)

    # End session
    summary = tracker.summary()
    print('\nSESSION SUMMARY')
    print(f"Learner: {name}")
    print(f"Total problems: {summary['total']}")
    print(f"Accuracy: {summary['accuracy']*100:.1f}%")
    print(f"Average response time: {summary['avg_time']:.2f}s")

    tracker.export_csv('session_log.csv')
    print('\nSession log saved to session_log.csv')

    # Recommend next level: use rule engine on full tracker
    rec = rule_engine.get_next_difficulty(difficulty, tracker)
    print(f'Recommended next starting difficulty: {rec}')


if __name__ == '__main__':
    run_session()
