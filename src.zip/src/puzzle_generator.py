import random
from typing import Tuple, Dict

OPS = ['+', '-', '*', '/']


def _divisible_pair(max_value):
    a = random.randint(1, max_value)
    b = random.randint(1, max_value)
    # make a divisible by b to keep integer division for children
    return a * b, b


def generate_problem(difficulty: str = 'Easy') -> Tuple[str, int, Dict]:
    """Return (question, answer, meta)
    difficulty: 'Easy', 'Medium', 'Hard'
    """
    difficulty = difficulty.capitalize()
    if difficulty == 'Easy':
        op = random.choice(['+', '-'])
        a = random.randint(0, 10)
        b = random.randint(0, 10)
    elif difficulty == 'Medium':
        op = random.choice(['+', '-', '*'])
        a = random.randint(0, 20)
        b = random.randint(0, 12)
    else:  # Hard
        op = random.choice(['+', '-', '*', '/'])
        if op == '/':
            a, b = _divisible_pair(12)
        else:
            a = random.randint(0, 50)
            b = random.randint(0, 20)

    if op == '+':
        ans = a + b
    elif op == '-':
        ans = a - b
    elif op == '*':
        ans = a * b
    else:  # '/'
        # integer division assumed
        ans = a // b

    question = f"{a} {op} {b} = ?"
    meta = {'difficulty': difficulty, 'op': op, 'a': a, 'b': b}
    return question, ans, meta


if __name__ == '__main__':
    # Quick demo
    for d in ['Easy', 'Medium', 'Hard']:
        q, a, m = generate_problem(d)
        print(d, q, a)
