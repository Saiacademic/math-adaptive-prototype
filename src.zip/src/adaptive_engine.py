from typing import List

DIFFICULTIES = ['Easy', 'Medium', 'Hard']


class RuleBasedAdaptiveEngine:
    def __init__(self):
        # thresholds are tunable
        self.increase_correct_streak = 3
        self.decrease_incorrect_in_window = 2
        # seconds; avg time below this and recent corrects => increase
        self.fast_time_threshold = 6.0
        # seconds; avg time above this => consider decreasing
        self.slow_time_threshold = 12.0

    def get_next_difficulty(self, current: str, tracker) -> str:
        current = current.capitalize()
        # Streak increase rule
        last = tracker.last_n(self.increase_correct_streak)
        if len(last) == self.increase_correct_streak and all(e.correct for e in last):
            # check speed
            avg_t = sum(e.response_time for e in last) / len(last)
            if avg_t <= self.fast_time_threshold and current != 'Hard':
                return DIFFICULTIES[DIFFICULTIES.index(current) + 1]

        # Recent trouble rule
        window = tracker.last_n(4)
        if len(window) >= 2:
            incorrects = sum(1 for e in window if not e.correct)
            avg_t = sum(e.response_time for e in window) / len(window)
            if incorrects >= self.decrease_incorrect_in_window or avg_t >= self.slow_time_threshold:
                if current != 'Easy':
                    return DIFFICULTIES[DIFFICULTIES.index(current) - 1]

        # otherwise keep
        return current


# Optional ML engine using small decision tree. It treats each question entry as a sample:
# features: last correctness (1/0), response_time, difficulty_idx
# target: next difficulty index relative -1,0,+1 (decrease,same,increase)
# Model is trained incrementally on session after there's some data. For the small prototype
# we retrain fully on available session entries.

try:
    from sklearn.tree import DecisionTreeClassifier
    import numpy as np

    class MLAdaptiveEngine:
        def __init__(self):
            self.clf = DecisionTreeClassifier(max_depth=4)
            self.trained = False

        def _entries_to_Xy(self, entries):
            # build samples: for each transition i -> i+1 create a sample
            X = []
            y = []
            for i in range(len(entries)-1):
                cur = entries[i]
                nxt = entries[i+1]
                cur_idx = DIFFICULTIES.index(cur.difficulty)
                nxt_idx = DIFFICULTIES.index(nxt.difficulty)
                rel = nxt_idx - cur_idx
                feat = [1 if cur.correct else 0, cur.response_time, cur_idx]
                X.append(feat)
                y.append(rel)
            return np.array(X), np.array(y)

        def train(self, tracker):
            entries = tracker.entries
            if len(entries) < 6:
                self.trained = False
                return
            X, y = self._entries_to_Xy(entries)
            if len(X) < 4:
                self.trained = False
                return
            self.clf.fit(X, y)
            self.trained = True

        def get_next_difficulty(self, current: str, tracker):
            if not self.trained:
                return current
            if not tracker.entries:
                return current
            last = tracker.entries[-1]
            feat = [[1 if last.correct else 0, last.response_time,
                     DIFFICULTIES.index(last.difficulty)]]
            pred_rel = self.clf.predict(feat)[0]
            new_idx = DIFFICULTIES.index(current) + int(pred_rel)
            new_idx = max(0, min(new_idx, len(DIFFICULTIES)-1))
            return DIFFICULTIES[new_idx]

except Exception:
    # sklearn not available — provide dummy MLAdaptiveEngine fallback
    class MLAdaptiveEngine:
        def __init__(self):
            self.trained = False

        def train(self, tracker):
            self.trained = False

        def get_next_difficulty(self, current: str, tracker):
            return current


if __name__ == '__main__':
    print('Adaptive engine demo')
