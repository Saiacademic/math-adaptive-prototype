import time
import csv
from dataclasses import dataclass, asdict
from typing import List


@dataclass
class Entry:
    timestamp: float
    question: str
    correct_answer: int
    user_answer: int
    correct: bool
    response_time: float
    difficulty: str


class PerformanceTracker:
    def __init__(self):
        self.entries: List[Entry] = []

    def add_entry(self, question, correct_answer, user_answer, correct, response_time, difficulty):
        e = Entry(time.time(), question, correct_answer,
                  user_answer, correct, response_time, difficulty)
        self.entries.append(e)

    def accuracy(self) -> float:
        if not self.entries:
            return 0.0
        return sum(1 for e in self.entries if e.correct) / len(self.entries)

    def avg_time(self) -> float:
        if not self.entries:
            return 0.0
        return sum(e.response_time for e in self.entries) / len(self.entries)

    def last_n(self, n: int):
        return self.entries[-n:]

    def export_csv(self, path='session_log.csv'):
        fieldnames = ['timestamp', 'question', 'correct_answer',
                      'user_answer', 'correct', 'response_time', 'difficulty']
        with open(path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            for e in self.entries:
                w.writerow(asdict(e))

    def summary(self):
        return {
            'total': len(self.entries),
            'accuracy': self.accuracy(),
            'avg_time': self.avg_time()
        }


if __name__ == '__main__':
    t = PerformanceTracker()
    t.add_entry('1+1', 2, 2, True, 1.2, 'Easy')
    t.add_entry('3*4', 12, 10, False, 4.1, 'Medium')
    print(t.summary())
